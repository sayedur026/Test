<?php
include 'header.php';
include 'menu.php';
?>
<!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
<!-- End WOWSlider.com HEAD section -->


			<!-- start banner Area -->
			<section class="banner-area relative" id="home" data-parallax="scroll" data-image-src="img/header-bg.jpg">
				<div class="overlay-bg overlay"></div>
				<div class="container">
					<div class="row fullscreen  d-flex align-items-center justify-content-end">
						<div class="banner-content col-lg-6 col-md-12">
							<h1>
								We Provide  <br>
								<span>Solutions</span> that <br>
								Brings <span>Joy</span>							
							</h1>
							<a href="contact.php" class="primary-btn2 header-btn text-uppercase">Hire Us Now!</a>
						</div>	
						<div class="banner-content col-lg-6 col-md-12">
							<!-- Start WOWSlider.com BODY section -->
							<div id="wowslider-container1">
							<div class="ws_images"><ul>
									<li><img src="data1/images/img_bg_1.jpg" alt="Image 1" title="" id="wows1_0"/></li>
									<li><img src="data1/images/img_bg_2.jpg" alt="Image 2" title="" id="wows1_1"/></li>
									<li><img src="data1/images/img_bg_3.jpg" alt="Image 3" title="" id="wows1_2"/></li>
									<li><img src="data1/images/img_bg_4.jpg" alt="Image 4" title="" id="wows1_3"/></li>
								</ul></div>
								<div class="ws_bullets"><div>
									<a href="#" title="Image 1"><span><img src="data1/tooltips/img_bg_1.jpg" alt="Image 1"/>1</span></a>
									<a href="#" title="Image 2"><span><img src="data1/tooltips/img_bg_2.jpg" alt="Image 2"/>2</span></a>
									<a href="#" title="Image 3"><span><img src="data1/tooltips/img_bg_3.jpg" alt="Image 3"/>3</span></a>
									<a href="#" title="Image 4"><span><img src="data1/tooltips/img_bg_4.jpg" alt="Image 4"/>4</span></a>
								</div></div></div>
							</div>	
							<script type="text/javascript" src="engine1/wowslider.js"></script>
							<script type="text/javascript" src="engine1/script.js"></script>
							<!-- End WOWSlider.com BODY section -->
						</div>						
					</div>
				</div>
			</section>
			<!-- End banner Area -->

<?php
include 'footer.php';
?>