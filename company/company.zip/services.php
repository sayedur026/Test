<?php
include 'header.php';
include 'menu.php';
?>

			<div class="whole-wrap">
				<div class="container">
					<div class="section-top-border">
						<h3 class="mb-30">What I do?</h3><br><br>
						<div class="row">
							<div class="col-md-4 text-center animate-box">
								<div class="services color-5">
									<span class="icon">
										<i class="icon-data"></i>
									</span>
									<div class="desc">
										<h3>Marketing</h3>
										<p>Enormous quality resources with vast marketing knowledge and experience</p>
									</div>
								</div>
							</div>
							<div class="col-md-4 text-center animate-box">
								<div class="services color-4">
									<span class="icon">
										<i class="icon-layers2"></i>
									</span>
									<div class="desc">
										<h3>Graphic Design</h3>
										<p>Excellent and experienced graphics designer with creative taste</p>
									</div>
								</div>
							</div>
							<div class="col-md-4 text-center animate-box">
								<div class="services color-6">
									<span class="icon">
										<i class="icon-phone3"></i>
									</span>
									<div class="desc">
										<h3>Risk Assessment</h3>
										<p>Super risk assessment techniques with market forecasting</p>
									</div>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-4 text-center animate-box">
								<div class="services color-1">
									<span class="icon">
										<i class="icon-bulb"></i>
									</span>
									<div class="desc">
										<h3>Innovative Ideas</h3>
										<p>New and Innovative ideas to grow business faster</p>
									</div>
								</div>
							</div>
							<div class="col-md-4 text-center animate-box">
								<div class="services color-2">
									<span class="icon">
										<i class="icon-data"></i>
									</span>
									<div class="desc">
										<h3>Market Strategy</h3>
										<p>Excellent market strategies to beat the compettitors</p>
									</div>
								</div>
							</div>
							<div class="col-md-4 text-center animate-box">
								<div class="services color-3">
									<span class="icon">
										<i class="icon-phone3"></i>
									</span>
									<div class="desc">
										<h3>Backups</h3>
										<p>Always available backup plan for emergency</p>
									</div>
								</div>
							</div>
						</div>
					</div>
					</div>
			</div>
			<!-- End Align Area -->

<?php
include 'footer.php';
?>